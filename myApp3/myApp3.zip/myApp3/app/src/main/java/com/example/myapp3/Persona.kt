package com.example.myapp3

class Persona(
    var nombre:String,
    var cedula:String
){

}